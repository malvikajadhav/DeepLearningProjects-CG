# All classes of NCD predicted
